const tours = [
    {
      id: "01",
      city: "Thailand",
      price: "Rs. 23400",
      imageLink: "https://www.thomascook.in/images/home-page-banners/2021/november/thailand.jpg",
     
    },
    {
        id: "02",
        city: "Dubai",
        price: "Rs. 26400",
        imageLink: "https://www.thomascook.in/images/site-banners/small-tile-dubai.jpg",
       
      },
      {
        id: "03",
        city: "Vietnam",
        price: "Rs. 19700",
        imageLink: "https://www.thomascook.in/images/home-page-banners/2021/november/vietnam.jpg",
       
      },
      {
        id: "04",
        city: "Mauritius",
        price: "Rs. 30500",
        imageLink: "https://www.thomascook.in/images/site-banners/Andaman.jpg",
       
      },
]
export default tours;