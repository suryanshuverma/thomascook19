const HoneymoonTourData = [
    {
        id: "01",
        city: "Maldivies",
        price: "Rs. 93900",
        imageLink: "https://www.thomascook.in/images/site-banners/Maldives.jpg",
       
      },
      {
          id: "02",
          city: "Greece",
          price: "Rs. 59900",
          imageLink: "https://www.thomascook.in/images/home-page-banners/2021/november/greece-tile.jpg",
         
        },
        {
          id: "03",
          city: "Himachal",
          price: "Rs. 12900",
          imageLink: "http://www.thomascook.in/images/home-page-banners/2023/june/Himachal.jpg",
         
        },
        {
          id: "04",
          city: "Kerala",
          price: "Rs. 72099",
          imageLink: "http://www.thomascook.in/images/home-page-banners/2023/june/Kerala.jpg",
         
        },

]

export default HoneymoonTourData;