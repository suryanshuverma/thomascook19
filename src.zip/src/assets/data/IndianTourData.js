const IndianTourData = [
    {
      id: "01",
      city: "Nepal",
      price: "Rs. 19999",
      imageLink: "https://www.thomascook.in/images/home-page-banners/2022/dec/nepal.jpg",
     
    },
    {
        id: "02",
        city: "Himachal",
        price: "Rs. 9800",
        imageLink: "https://www.thomascook.in/images/site-banners/pck_img_himachal.jpg",
       
      },
      {
        id: "03",
        city: "Kerala",
        price: "Rs. 11949",
        imageLink: "https://www.thomascook.in/images/site-banners/2023/Kerala.jpg",
       
      },
      {
        id: "04",
        city: "Andaman",
        price: "Rs. 19200",
        imageLink: "http://www.thomascook.in/images/home-page-banners/2023/june/Kerala.jpg",
       
      },
]
export default IndianTourData;