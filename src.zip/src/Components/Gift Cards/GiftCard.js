import React from 'react'

const GiftCard = () => {
  return (
    <div>GiftCard</div>
  )
}

export default GiftCard