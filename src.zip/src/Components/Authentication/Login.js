import React,{useState} from 'react'
import { loginUser } from '../../services/user-service';
import { doLogin } from './Auth';
const Login = () => {
    const [loginDetail, setLoginDetail] = useState({
        emailId: "",
        password: "",
        role:"",

      });

      const handleChange = (event, field) => {
        let actualValue = event.target.value;
        setLoginDetail({
          ...loginDetail,
          [field]: actualValue,
        });
      };


      const handleSubmit = (event) => {
        event.preventDefault();
        console.log(loginDetail);
      

      //submit data to server to generate token
      loginUser(loginDetail).then((data)=>{
        console.log(data.jwtToken);

          //save the data to localstorage
          doLogin(data.jwtToken, () => {
            console.log("login detail is saved to localstorage");
          })
        //     //redirect to user dashboard page
        //     userContxtData.setUser({
        //       data: data.user,
        //       login: true,
        //     });
        //     navigate("/user/dashboard");
        //   });
  




      }).catch(error =>{
        console.log(error)
      })
    }
  return (
    <>
    Enter Email: <input type="email" value={loginDetail.emailId}  
     onChange={(e) => handleChange(e, "emailId")}/>
    Enter  password: <input type="password" value={loginDetail.password}
         onChange={(e) => handleChange(e, "password")}/>
    Enter Role: <input type="text" value={loginDetail.role} 
         onChange={(e) => handleChange(e, "role")}/>
         <button onClick={handleSubmit}>Submit</button>
    </>
  )
}

export default Login