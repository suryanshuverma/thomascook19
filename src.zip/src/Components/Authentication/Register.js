import React, { useState } from 'react'
import axios from 'axios'
import { getLocation } from '../../services/user-service'
import { privateAxios } from '../../services/helper'

const Register = () => {
  // const [formData,setFormData] = useState({
  //   firstName: "",
  //   lastName: "",
  //   age: "",
  //   emailId:"",
  //   password: "",
  // }) 
  // const [data,setData] = useState([]);

  // const [firstName,lastName,age,emailId,password] = formData;
  // const handleChange = (e) =>{
  // setFormData({...formData, [e.target.name]:e.target.value })
  // }
  // const handleSubmit = (e)=>{
  //   e.preventDefault();
  //   setData([...data,formData]);
  // }
 const data = {
  firstName:"",
   lastName:"",
  age: "",
  emailId:"",
  password:"",

}
const [inputData,setInputData] = useState(data)
const handleData = (e)=>{

  setInputData({...inputData, [e.target.name]:e.target.value})
}
const handleSubmit = (e) => {
  e.preventDefault();
  axios.post("http://localhost:8080/api/user/register",inputData).then((response)=>{
    console.log(response);
}
  )
// axios.get("http://localhost:8080/api/location/fetch").then((response)=>{
//   console.log(response);

}
const handleLocation = (e) =>{
  e.preventDefault();
privateAxios.get("http://localhost:8080/api/location/fetch").then((response)=>console.log(response.data));
}

  return (<>
    <div>Register me</div>
    Fname: <input type="text" name="firstName" value={inputData.firstName} onChange={handleData} />
   Lname:  <input type="text" name="lastName" value={inputData.lastName} onChange={handleData} />
age: <input type="number"   name="age" value={inputData.age} onChange={handleData}/>
email: <input type="email" name="emailId"  value={inputData.emailId} onChange={handleData} />
password: <input type="password"  name="password" value={inputData.password} onChange={handleData} />
<button type="button" onClick={handleSubmit}> Submit</button>
<button onClick={handleLocation}>getLocation</button>
</>
  )
}

export default Register;