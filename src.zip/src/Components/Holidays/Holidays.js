import React from 'react'

const Holidays = () => {
  return (
    <div>Holidays</div>
  )
}

export default Holidays