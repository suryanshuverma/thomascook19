import { useState,useEffect } from "react";
import { useLocation } from "react-router-dom";
import { format } from "date-fns";
import React from 'react'
import { DateRange } from "react-date-range";
import SearchItem from "./SearchItem";
import { privateAxios } from '../../services/helper';
import "./list.css";
const List = () => {
    const location = useLocation();
    // console.log(location)
    const [destination, setDestination] = useState(location.state.destination);
    const [date, setDate] = useState(location.state.date);
    const [openDate, setOpenDate] = useState(false);
    const [options, setOptions] = useState(location.state.options);
    const [id, setId] = useState();
    const [hotelData,setHotelData] = useState();
    const fetchHotel =async()=>{
      const response = await privateAxios.get("http://localhost:8080/api/location/fetch")
      const result = await response.data.locations;
      const mani= result.filter((user)=>{
        const nani= user.city.includes(destination)
        return nani;
      }) 
      setId(mani[0].id)
        }
      const fetchHotelByLocation = async()=>{
          const response2 =   await privateAxios.get(`http://localhost:8080/api/hotel/location?locationId=${id}`)
            // .then((response)=>console.log(response.data.hotels))
            const result2= await response2.data.hotels;
            // console.log(result2);
            setHotelData(result2);
            


            }
            useEffect(()=>{
              fetchHotel();
            //  return ()=>{
            //   if(id!=undefined){
            //   fetchHotelByLocation();
            //   }

          
                },[])
                

                // setTimeout(()=>{
                //   if(id!= undefined){
                //   fetchHotelByLocation();
                //   }
                // },1000)
const onSearch = ()=>{
  fetchHotelByLocation();
//  console.log(hotelData)
}


  return (
  <>
      <div>
    {/* {console.log(hotelData)} */}
      <div className="listContainer">
        <div className="listWrapper">
          <div className="listSearch">
            <h1 className="lsTitle">Search</h1>
            <div className="lsItem">
              <label>Destination</label>
              <input placeholder={destination} type="text" />
            </div>
            <div className="lsItem">
              <label>Check-in Date</label>
              <span onClick={() => setOpenDate(!openDate)}>{`${format(
                date[0].startDate,
                "MM/dd/yyyy"
              )} to ${format(date[0].endDate, "MM/dd/yyyy")}`}</span>
              {openDate && (
                <DateRange
                  onChange={(item) => setDate([item.selection])}
                  minDate={new Date()}
                  ranges={date}
                />
              )}
              {/* {console.log(hotelData[0].name)} */}
            </div>
            <div className="lsItem">
              <label>Options</label>
              <div className="lsOptions">
                <div className="lsOptionItem">
                  <span className="lsOptionText">
                    Min price <small>per night</small>
                  </span>
                  <input type="number" className="lsOptionInput" />
                </div>
                <div className="lsOptionItem">
                  <span className="lsOptionText">
                    Max price <small>per night</small>
                  </span>
                  <input type="number" className="lsOptionInput" />
                </div>
                <div className="lsOptionItem">
                  <span className="lsOptionText">Adult</span>
                  <input
                    type="number"
                    min={1}
                    className="lsOptionInput"
                    placeholder={options.adult}
                  />
                </div>
                <div className="lsOptionItem">
                  <span className="lsOptionText">Children</span>
                  <input
                    type="number"
                    min={0}
                    className="lsOptionInput"
                    placeholder={options.children}
                  />
                </div>
                <div className="lsOptionItem">
                  <span className="lsOptionText">Room</span>
                  <input
                    type="number"
                    min={1}
                    className="lsOptionInput"
                    placeholder={options.room}
                  />
                </div>
              </div>
            </div>
            <button onClick={onSearch}>Search</button>
          </div>
          <div className="listResult">
          
{hotelData &&
hotelData.map(item=>(
<SearchItem hotelData={item} key={item.id} />
))

}
            
           
          </div>
        </div>
      </div>
    </div>
    
  
  </>
  )
}

export default List