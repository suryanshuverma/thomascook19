import React from 'react'

const Offers = () => {
  return (
    <div>Offers</div>
  )
}

export default Offers